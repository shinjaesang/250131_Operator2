package logic.controller;

import java.util.Random;
import java.util.Scanner;

public class Function {
	//Field(멤버변수)
	Scanner sc = new Scanner(System.in);
	
	//Method	
	/**
	과제 4 : 
	처리내용
	1. 정수 두 개와 연산문자 하나를 키보드로 입력받음
		첫번째 정수 : 12
		두번째 정수 : 5
		연산문자 : x
	2. 두 정수값은 int 변수에 저장
	3. 연산문자는 char 변수에 저장
	4. switch 문 사용
		: 연산 문자가 '+' 이면, 두 정수의 합 계산
			'-' 면 , 두 정수의 차 계산
			'x' 또는 'X' 이면, 두 정수의 곱
			'/' 이면 , 두 정수의 나누기 몫
			단, 나누는 수(두번째 정수)가 0이면
			"0으로 나눌 수 없습니다." 출력되게 하고, 
			결과값 0 처리함
		을 계산처리 후 
	5. 결과 출력
	    예> 10 x 20 = 200
	*/
	public void calculator(){
		System.out.print("첫번째 정수 : ");
		int first = sc.nextInt();
		System.out.print("두번째 정수 : ");
		int second = sc.nextInt();
		System.out.print("연산문자 (+, -, x, /) : ");
		char op = sc.next().charAt(0);

		int result = 0;
		switch(op){
		case '+':  result = first + second;  break;
		case '-':  result = first - second;  break;
		case 'x':  
		case 'X':  result = first * second;  break;
		case '/':  if(second == 0){
					System.out.println("0으로 나눌 수 없습니다.");					
				 }else {
					 result = first / second; 
				 }
				 break;
		}

		System.out.println(first + " " + op + " " + second + " = " + result);
	}
	
	
	/**
	과제 5 : 
	처리내용
	1. 키보드로 두 개의 정수를 입력받음
	2. 두 정수중 작은 값을 시작값으로,
	    큰 값을 종료값으로 사용함
	3. 작은값에서 큰값까지 정수의 합계를 구함
		: for 문 사용
	예>
		12  3    입력시
		3 ~ 12 까지 정수의 합을 구함
		3+4+5+....+12
	4. 합계 출력 처리
		3부터 12까지 정수들의 합계 : 결과값
	*/
	public void totalCalculator(){
		System.out.print("첫번째 정수 : ");
		int first = sc.nextInt();
		System.out.print("두번째 정수 : ");
		int second = sc.nextInt();
		
		int min, max;
		if(first > second) {
			max = first;
			min = second;
		}else {
			max = second;
			min = first;
		}
		
		int sum = 0;
		for(int su = min; su <= max; su++) {
			sum += su;
			
			System.out.print(su);
			if(su < max) {
				System.out.print("+");
			}
		}
		
		System.out.println(min + "부터 " + max + "까지 정수들의 합계 : " + sum);
	}
	
	/**
	과제 6 : 
	처리내용 : 신상정보들을 자료형에 맞춰 변수에 기록하고,
	변수에 기록된 값을 출력 확인함.
	실행내용 : 콘솔창에 본인의 신상정보가 출력되게 함
	출력예>
	이름 : 홍길동
	나이 : 26 세
	성별 : 남자
	성격 : 고집불통
	*/
	public void profile(){
		System.out.print("이름 : ");
		String name = sc.next();
		System.out.print("나이 : ");
		int age = sc.nextInt();
		System.out.print("성별[남/여] : ");
		char gender = sc.next().charAt(0);
		System.out.print("성격 : ");
		sc.nextLine();
		String personality = sc.nextLine();
		
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age + "세");
		System.out.println("성별 : " + gender + "자");
		System.out.println("성격 : " + personality);
	}
	
	/**
	과제 7 : 
	처리내용
	변수 선언하고, 키보드로 입력받은 값들을 변수에 기록하고
	변수값을 화면에 출력 확인함
	=> 변수 
	학생이름 (String)
	학년 (int)
	반 (int)
	번호 (int)
	성별(M/F) (char)	//문자열로 입력받은 후, 문자하나 분리해야 함
	성적 (double) //소숫점 아래 둘째자리까지 입력받음
	학점 (char)

	점수가 90 이상이면 학점을 A 로 처리
	        80 이상 90 미만 B
		70 이상 80 미만 C
		60 이상 70 미만 D
		60 미만 F


	출력예>
	3학년 2반 25번 남학생 홍길동의 점수는 95.5이고, A 학점입니다.
	** 남학생/여학생은 성별 변수의 값을 사용해서 삼항연산자로 처리함
	*/
	public void sungjuk(){
		System.out.print("학생이름 : ");
		String studentName = sc.next();
		System.out.print("학년 : ");
		int year = sc.nextInt();
		System.out.print("반 : ");
		int ban = sc.nextInt();
		System.out.print("번호 : ");
		int studentNo = sc.nextInt();
		System.out.print("성벌(M/F) : ");
		char gender = sc.next().charAt(0);
		System.out.print("성적(소숫점 아래 둘째자리까지 입력) : ");
		double score = sc.nextDouble();
		
		char grade = (score >= 90)? 'A': ((score >= 80)? 'B': ((score >= 70)? 'C': ((score >= 60)? 'D': 'F')));
		
		System.out.println(year + "학년 " + ban + "반 " + studentNo + "번 " 
				+ ((gender == 'M')? "남": "여") + "학생 " + studentName + "의 점수는 " + score + "이고, " 
				+ grade + " 학점입니다.");
	}
	
	/**
	과제 8 : 
	처리내용
	 1~100 사이의 정수중 임의의 정수를 하나 발생시켜(Math.random())
   1부터 발생된 정수까지의 합계를 구하여 출력함
	*/	
	public void sumRandomNumber(){
		int randomValue = (int)(Math.random() * 100) + 1;
		int sum = 0;
		
		for(int su = 1; su <= randomValue; su++) {
			sum += su;
		}
		
		System.out.println("1 ~ " + randomValue + "까지의 정수의 합계 : " + sum);
	}
	
	/**
	과제 9
	정수를 하나 입력받아, 그 수가 양수일 때만 그 수의 구구단이
   출력되게 함.
   단, 곱하기 결과가 입력받은 정수의 배수인 값을 출력에서 제외함.
 - if문과 for문, continue문 사용
 - 메소드명 : public void continueGugudan(){}
	ex>
	단수 : 3
	제외할 배수 : 9

	3 * 1 = 3
	3 * 2 = 6	
	3 * 4 = 12
	3 * 5 = 15	
	3 * 7 = 21
	3 * 8 = 24	
	================
	정수 하나 입력 : -7
	양수가 아닙니다.
	*/
	public void continueGugudan(){
		System.out.print("단수 : ");
		int dan = sc.nextInt();
		
		if(dan > 0) {
			System.out.print("제외할 배수 : ");
			int value = sc.nextInt();
			
			for(int su = 1; su < 10; su++) {
				int result = dan * su;
				if(result % value == 0) {
					continue;
				}
				System.out.println(dan + "*" + su + "=" + result);
			}
		}else {
			System.out.println("양수가 아닙니다.");
		}
	}
	
	/**
	과제 10
	1. 두 개의 주사위가 만들어 낼 수 있는 모든 경우의 수중(random)
	2. 두 주사위 눈의 합이 입력된 수와 같은 경우 "맞췄습니다." 출력
	3. 입력값과 다르면 "틀렸습니다." 출력함.
	4. do ~ while 문으로 반복되게 함
	5. "계속하시겠습니까?(y/n) : " 에서 'n' 또는 'N' 입력시 반복종료됨
	*/
	public void shutNumber(){
		Random r = new Random();
		char answer;
		do {
			int dice1 = r.nextInt(6) + 1;
			int dice2 = r.nextInt(6) + 1;
			int sum = dice1 + dice2;
			
			System.out.print("두 주사위의 눈의 합계는 ? ");
			int num = sc.nextInt();
			
			if(sum == num) {
				System.out.println("맞췄습니다."); 				
			}else {
				System.out.println("틀렸습니다.");
			}
			
			System.out.print("게속 하시겠습니까? (y/n) : ");
			answer = sc.next().toUpperCase().charAt(0);
			
		}while(answer == 'Y');	
		
	}
}
