package logic.test;

import logic.view.Menu;

public class TestMain {

	public static void main(String[] args) {
		// 연산자 연습 과제 실행 테스트용
		Menu.displayMenu();
		System.out.println("지역변수/연산자/제어문 연습 프로그램을 종료합니다.");
	}

}
